package org.example;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.HttpURLConnection;
import java.net.*;

public class Main {
    public static void main(String[] args) {

        HttpURLConnection connection = null;
        int code;
        String result = "";

        try {
            URL check = new URL("http://www.google.com/");
            connection = (HttpURLConnection) check.openConnection();
            connection.setRequestMethod("HEAD");
            code = connection.getResponseCode();

            System.out.println(code);

            if (code != 200) {
                //TODO: Send Email

                System.out.println("Not a success.");

            } else {
                System.out.println("Success.");
            }

            result = "Status: " + code;

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        System.out.println("This test ran. " + result);


    }
}

